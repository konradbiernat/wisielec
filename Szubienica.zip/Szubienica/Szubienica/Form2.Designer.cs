﻿namespace Szubienica
{
    partial class frmHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.HangImage = new System.Windows.Forms.PictureBox();
            this.cmdA = new System.Windows.Forms.Button();
            this.cmdG = new System.Windows.Forms.Button();
            this.cmdF = new System.Windows.Forms.Button();
            this.cmdĘ = new System.Windows.Forms.Button();
            this.cmdE = new System.Windows.Forms.Button();
            this.cmdD = new System.Windows.Forms.Button();
            this.cmdĆ = new System.Windows.Forms.Button();
            this.cmdC = new System.Windows.Forms.Button();
            this.cmdB = new System.Windows.Forms.Button();
            this.cmdĄ = new System.Windows.Forms.Button();
            this.cmdI = new System.Windows.Forms.Button();
            this.cmdJ = new System.Windows.Forms.Button();
            this.cmdK = new System.Windows.Forms.Button();
            this.cmdL = new System.Windows.Forms.Button();
            this.cmdŁ = new System.Windows.Forms.Button();
            this.cmdM = new System.Windows.Forms.Button();
            this.cmdN = new System.Windows.Forms.Button();
            this.cmdŃ = new System.Windows.Forms.Button();
            this.cmdH = new System.Windows.Forms.Button();
            this.cmdR = new System.Windows.Forms.Button();
            this.cmdQ = new System.Windows.Forms.Button();
            this.cmdP = new System.Windows.Forms.Button();
            this.cmdó = new System.Windows.Forms.Button();
            this.cmdO = new System.Windows.Forms.Button();
            this.cmdV = new System.Windows.Forms.Button();
            this.cmdU = new System.Windows.Forms.Button();
            this.cmdT = new System.Windows.Forms.Button();
            this.cmdŚ = new System.Windows.Forms.Button();
            this.cmdS = new System.Windows.Forms.Button();
            this.cmdŹ = new System.Windows.Forms.Button();
            this.cmdZ = new System.Windows.Forms.Button();
            this.cmdY = new System.Windows.Forms.Button();
            this.cmdX = new System.Windows.Forms.Button();
            this.cmdW = new System.Windows.Forms.Button();
            this.cmdŻ = new System.Windows.Forms.Button();
            this.lblResult = new System.Windows.Forms.Label();
            this.lblShowWord = new System.Windows.Forms.Label();
            this.button35 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.HangImage)).BeginInit();
            this.SuspendLayout();
            // 
            // HangImage
            // 
            this.HangImage.Image = global::Szubienica.Properties.Resources.Hang1;
            this.HangImage.Location = new System.Drawing.Point(217, 12);
            this.HangImage.Name = "HangImage";
            this.HangImage.Size = new System.Drawing.Size(74, 200);
            this.HangImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.HangImage.TabIndex = 0;
            this.HangImage.TabStop = false;
            // 
            // cmdA
            // 
            this.cmdA.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdA.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdA.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdA.Location = new System.Drawing.Point(107, 271);
            this.cmdA.Name = "cmdA";
            this.cmdA.Size = new System.Drawing.Size(19, 28);
            this.cmdA.TabIndex = 1;
            this.cmdA.Text = "a";
            this.cmdA.UseVisualStyleBackColor = true;
            this.cmdA.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdG
            // 
            this.cmdG.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdG.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdG.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdG.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdG.Location = new System.Drawing.Point(249, 271);
            this.cmdG.Name = "cmdG";
            this.cmdG.Size = new System.Drawing.Size(19, 28);
            this.cmdG.TabIndex = 10;
            this.cmdG.Text = "g";
            this.cmdG.UseVisualStyleBackColor = true;
            this.cmdG.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdF
            // 
            this.cmdF.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdF.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdF.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdF.Location = new System.Drawing.Point(233, 271);
            this.cmdF.Name = "cmdF";
            this.cmdF.Size = new System.Drawing.Size(19, 28);
            this.cmdF.TabIndex = 11;
            this.cmdF.Text = "f";
            this.cmdF.UseVisualStyleBackColor = true;
            this.cmdF.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdĘ
            // 
            this.cmdĘ.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdĘ.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdĘ.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdĘ.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdĘ.Location = new System.Drawing.Point(217, 271);
            this.cmdĘ.Name = "cmdĘ";
            this.cmdĘ.Size = new System.Drawing.Size(19, 28);
            this.cmdĘ.TabIndex = 12;
            this.cmdĘ.Text = "ę";
            this.cmdĘ.UseVisualStyleBackColor = true;
            this.cmdĘ.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdE
            // 
            this.cmdE.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdE.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdE.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdE.Location = new System.Drawing.Point(202, 271);
            this.cmdE.Name = "cmdE";
            this.cmdE.Size = new System.Drawing.Size(19, 28);
            this.cmdE.TabIndex = 13;
            this.cmdE.Text = "e";
            this.cmdE.UseVisualStyleBackColor = true;
            this.cmdE.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdD
            // 
            this.cmdD.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdD.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdD.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdD.Location = new System.Drawing.Point(186, 271);
            this.cmdD.Name = "cmdD";
            this.cmdD.Size = new System.Drawing.Size(19, 28);
            this.cmdD.TabIndex = 14;
            this.cmdD.Text = "d";
            this.cmdD.UseVisualStyleBackColor = true;
            this.cmdD.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdĆ
            // 
            this.cmdĆ.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdĆ.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdĆ.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdĆ.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdĆ.Location = new System.Drawing.Point(170, 271);
            this.cmdĆ.Name = "cmdĆ";
            this.cmdĆ.Size = new System.Drawing.Size(19, 28);
            this.cmdĆ.TabIndex = 15;
            this.cmdĆ.Text = "ć";
            this.cmdĆ.UseVisualStyleBackColor = true;
            this.cmdĆ.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdC
            // 
            this.cmdC.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdC.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdC.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdC.Location = new System.Drawing.Point(154, 271);
            this.cmdC.Name = "cmdC";
            this.cmdC.Size = new System.Drawing.Size(19, 28);
            this.cmdC.TabIndex = 16;
            this.cmdC.Text = "c";
            this.cmdC.UseVisualStyleBackColor = true;
            this.cmdC.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdB
            // 
            this.cmdB.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdB.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdB.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdB.Location = new System.Drawing.Point(138, 271);
            this.cmdB.Name = "cmdB";
            this.cmdB.Size = new System.Drawing.Size(19, 28);
            this.cmdB.TabIndex = 17;
            this.cmdB.Text = "b";
            this.cmdB.UseVisualStyleBackColor = true;
            this.cmdB.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdĄ
            // 
            this.cmdĄ.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdĄ.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdĄ.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdĄ.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdĄ.Location = new System.Drawing.Point(122, 271);
            this.cmdĄ.Name = "cmdĄ";
            this.cmdĄ.Size = new System.Drawing.Size(19, 28);
            this.cmdĄ.TabIndex = 18;
            this.cmdĄ.Text = "ą";
            this.cmdĄ.UseVisualStyleBackColor = true;
            this.cmdĄ.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdI
            // 
            this.cmdI.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdI.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdI.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdI.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdI.Location = new System.Drawing.Point(280, 271);
            this.cmdI.Name = "cmdI";
            this.cmdI.Size = new System.Drawing.Size(19, 28);
            this.cmdI.TabIndex = 28;
            this.cmdI.Text = "i";
            this.cmdI.UseVisualStyleBackColor = true;
            this.cmdI.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdJ
            // 
            this.cmdJ.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdJ.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdJ.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdJ.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdJ.Location = new System.Drawing.Point(296, 271);
            this.cmdJ.Name = "cmdJ";
            this.cmdJ.Size = new System.Drawing.Size(19, 28);
            this.cmdJ.TabIndex = 27;
            this.cmdJ.Text = "j";
            this.cmdJ.UseVisualStyleBackColor = true;
            this.cmdJ.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdK
            // 
            this.cmdK.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdK.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdK.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdK.Location = new System.Drawing.Point(312, 271);
            this.cmdK.Name = "cmdK";
            this.cmdK.Size = new System.Drawing.Size(19, 28);
            this.cmdK.TabIndex = 26;
            this.cmdK.Text = "k";
            this.cmdK.UseVisualStyleBackColor = true;
            this.cmdK.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdL
            // 
            this.cmdL.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdL.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdL.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdL.Location = new System.Drawing.Point(328, 271);
            this.cmdL.Name = "cmdL";
            this.cmdL.Size = new System.Drawing.Size(19, 28);
            this.cmdL.TabIndex = 25;
            this.cmdL.Text = "l";
            this.cmdL.UseVisualStyleBackColor = true;
            this.cmdL.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdŁ
            // 
            this.cmdŁ.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdŁ.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdŁ.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdŁ.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdŁ.Location = new System.Drawing.Point(344, 271);
            this.cmdŁ.Name = "cmdŁ";
            this.cmdŁ.Size = new System.Drawing.Size(19, 28);
            this.cmdŁ.TabIndex = 24;
            this.cmdŁ.Text = "ł";
            this.cmdŁ.UseVisualStyleBackColor = true;
            this.cmdŁ.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdM
            // 
            this.cmdM.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdM.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdM.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdM.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdM.Location = new System.Drawing.Point(359, 271);
            this.cmdM.Name = "cmdM";
            this.cmdM.Size = new System.Drawing.Size(19, 28);
            this.cmdM.TabIndex = 23;
            this.cmdM.Text = "m";
            this.cmdM.UseVisualStyleBackColor = true;
            this.cmdM.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdN
            // 
            this.cmdN.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdN.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdN.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdN.Location = new System.Drawing.Point(375, 271);
            this.cmdN.Name = "cmdN";
            this.cmdN.Size = new System.Drawing.Size(19, 28);
            this.cmdN.TabIndex = 22;
            this.cmdN.Text = "n";
            this.cmdN.UseVisualStyleBackColor = true;
            this.cmdN.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdŃ
            // 
            this.cmdŃ.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdŃ.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdŃ.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdŃ.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdŃ.Location = new System.Drawing.Point(107, 305);
            this.cmdŃ.Name = "cmdŃ";
            this.cmdŃ.Size = new System.Drawing.Size(19, 28);
            this.cmdŃ.TabIndex = 21;
            this.cmdŃ.Text = "ń";
            this.cmdŃ.UseVisualStyleBackColor = true;
            this.cmdŃ.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdH
            // 
            this.cmdH.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdH.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdH.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdH.Location = new System.Drawing.Point(264, 271);
            this.cmdH.Name = "cmdH";
            this.cmdH.Size = new System.Drawing.Size(19, 28);
            this.cmdH.TabIndex = 19;
            this.cmdH.Text = "h";
            this.cmdH.UseVisualStyleBackColor = true;
            this.cmdH.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdR
            // 
            this.cmdR.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdR.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdR.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdR.Location = new System.Drawing.Point(185, 305);
            this.cmdR.Name = "cmdR";
            this.cmdR.Size = new System.Drawing.Size(19, 28);
            this.cmdR.TabIndex = 29;
            this.cmdR.Text = "r";
            this.cmdR.UseVisualStyleBackColor = true;
            this.cmdR.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdQ
            // 
            this.cmdQ.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdQ.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdQ.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdQ.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdQ.Location = new System.Drawing.Point(169, 305);
            this.cmdQ.Name = "cmdQ";
            this.cmdQ.Size = new System.Drawing.Size(19, 28);
            this.cmdQ.TabIndex = 30;
            this.cmdQ.Text = "q";
            this.cmdQ.UseVisualStyleBackColor = true;
            this.cmdQ.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdP
            // 
            this.cmdP.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdP.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdP.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdP.Location = new System.Drawing.Point(153, 305);
            this.cmdP.Name = "cmdP";
            this.cmdP.Size = new System.Drawing.Size(19, 28);
            this.cmdP.TabIndex = 31;
            this.cmdP.Text = "p";
            this.cmdP.UseVisualStyleBackColor = true;
            this.cmdP.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdó
            // 
            this.cmdó.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdó.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdó.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdó.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdó.Location = new System.Drawing.Point(138, 305);
            this.cmdó.Name = "cmdó";
            this.cmdó.Size = new System.Drawing.Size(19, 28);
            this.cmdó.TabIndex = 32;
            this.cmdó.Text = "ó";
            this.cmdó.UseVisualStyleBackColor = true;
            this.cmdó.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdO
            // 
            this.cmdO.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdO.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdO.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdO.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdO.Location = new System.Drawing.Point(122, 305);
            this.cmdO.Name = "cmdO";
            this.cmdO.Size = new System.Drawing.Size(19, 28);
            this.cmdO.TabIndex = 33;
            this.cmdO.Text = "o";
            this.cmdO.UseVisualStyleBackColor = true;
            this.cmdO.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdV
            // 
            this.cmdV.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdV.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdV.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdV.Location = new System.Drawing.Point(264, 305);
            this.cmdV.Name = "cmdV";
            this.cmdV.Size = new System.Drawing.Size(19, 28);
            this.cmdV.TabIndex = 34;
            this.cmdV.Text = "v";
            this.cmdV.UseVisualStyleBackColor = true;
            this.cmdV.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdU
            // 
            this.cmdU.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdU.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdU.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdU.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdU.Location = new System.Drawing.Point(248, 305);
            this.cmdU.Name = "cmdU";
            this.cmdU.Size = new System.Drawing.Size(19, 28);
            this.cmdU.TabIndex = 35;
            this.cmdU.Text = "u";
            this.cmdU.UseVisualStyleBackColor = true;
            this.cmdU.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdT
            // 
            this.cmdT.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdT.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdT.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdT.Location = new System.Drawing.Point(232, 305);
            this.cmdT.Name = "cmdT";
            this.cmdT.Size = new System.Drawing.Size(19, 28);
            this.cmdT.TabIndex = 36;
            this.cmdT.Text = "t";
            this.cmdT.UseVisualStyleBackColor = true;
            this.cmdT.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdŚ
            // 
            this.cmdŚ.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdŚ.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdŚ.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdŚ.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdŚ.Location = new System.Drawing.Point(217, 305);
            this.cmdŚ.Name = "cmdŚ";
            this.cmdŚ.Size = new System.Drawing.Size(19, 28);
            this.cmdŚ.TabIndex = 37;
            this.cmdŚ.Text = "ś";
            this.cmdŚ.UseVisualStyleBackColor = true;
            this.cmdŚ.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdS
            // 
            this.cmdS.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdS.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdS.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdS.Location = new System.Drawing.Point(201, 305);
            this.cmdS.Name = "cmdS";
            this.cmdS.Size = new System.Drawing.Size(19, 28);
            this.cmdS.TabIndex = 38;
            this.cmdS.Text = "s";
            this.cmdS.UseVisualStyleBackColor = true;
            this.cmdS.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdŹ
            // 
            this.cmdŹ.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdŹ.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdŹ.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdŹ.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdŹ.Location = new System.Drawing.Point(343, 305);
            this.cmdŹ.Name = "cmdŹ";
            this.cmdŹ.Size = new System.Drawing.Size(19, 28);
            this.cmdŹ.TabIndex = 39;
            this.cmdŹ.Text = "ź";
            this.cmdŹ.UseVisualStyleBackColor = true;
            this.cmdŹ.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdZ
            // 
            this.cmdZ.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdZ.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdZ.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdZ.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdZ.Location = new System.Drawing.Point(327, 305);
            this.cmdZ.Name = "cmdZ";
            this.cmdZ.Size = new System.Drawing.Size(19, 28);
            this.cmdZ.TabIndex = 40;
            this.cmdZ.Text = "z";
            this.cmdZ.UseVisualStyleBackColor = true;
            this.cmdZ.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdY
            // 
            this.cmdY.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdY.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdY.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdY.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdY.Location = new System.Drawing.Point(311, 305);
            this.cmdY.Name = "cmdY";
            this.cmdY.Size = new System.Drawing.Size(19, 28);
            this.cmdY.TabIndex = 41;
            this.cmdY.Text = "y";
            this.cmdY.UseVisualStyleBackColor = true;
            this.cmdY.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdX
            // 
            this.cmdX.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdX.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdX.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdX.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdX.Location = new System.Drawing.Point(295, 305);
            this.cmdX.Name = "cmdX";
            this.cmdX.Size = new System.Drawing.Size(19, 28);
            this.cmdX.TabIndex = 42;
            this.cmdX.Text = "x";
            this.cmdX.UseVisualStyleBackColor = true;
            this.cmdX.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdW
            // 
            this.cmdW.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdW.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdW.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdW.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdW.Location = new System.Drawing.Point(279, 305);
            this.cmdW.Name = "cmdW";
            this.cmdW.Size = new System.Drawing.Size(19, 28);
            this.cmdW.TabIndex = 43;
            this.cmdW.Text = "w";
            this.cmdW.UseVisualStyleBackColor = true;
            this.cmdW.Click += new System.EventHandler(this.guessClick);
            // 
            // cmdŻ
            // 
            this.cmdŻ.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.cmdŻ.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdŻ.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmdŻ.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cmdŻ.Location = new System.Drawing.Point(359, 305);
            this.cmdŻ.Name = "cmdŻ";
            this.cmdŻ.Size = new System.Drawing.Size(19, 28);
            this.cmdŻ.TabIndex = 44;
            this.cmdŻ.Text = "ż";
            this.cmdŻ.UseVisualStyleBackColor = true;
            this.cmdŻ.Click += new System.EventHandler(this.guessClick);
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Location = new System.Drawing.Point(407, 94);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(0, 13);
            this.lblResult.TabIndex = 45;
            // 
            // lblShowWord
            // 
            this.lblShowWord.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblShowWord.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblShowWord.Location = new System.Drawing.Point(153, 224);
            this.lblShowWord.Name = "lblShowWord";
            this.lblShowWord.Size = new System.Drawing.Size(201, 35);
            this.lblShowWord.TabIndex = 46;
            this.lblShowWord.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button35
            // 
            this.button35.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.button35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button35.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button35.Location = new System.Drawing.Point(384, 305);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(98, 28);
            this.button35.TabIndex = 47;
            this.button35.Text = "Jeszcze raz";
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Click += new System.EventHandler(this.try_again);
            // 
            // button1
            // 
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSteelBlue;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(12, 305);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(89, 28);
            this.button1.TabIndex = 48;
            this.button1.Text = "Menu";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.GoBack);
            // 
            // frmHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(494, 342);
            this.ControlBox = false;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.lblShowWord);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.cmdŻ);
            this.Controls.Add(this.cmdW);
            this.Controls.Add(this.cmdX);
            this.Controls.Add(this.cmdY);
            this.Controls.Add(this.cmdZ);
            this.Controls.Add(this.cmdŹ);
            this.Controls.Add(this.cmdS);
            this.Controls.Add(this.cmdŚ);
            this.Controls.Add(this.cmdT);
            this.Controls.Add(this.cmdU);
            this.Controls.Add(this.cmdV);
            this.Controls.Add(this.cmdO);
            this.Controls.Add(this.cmdó);
            this.Controls.Add(this.cmdP);
            this.Controls.Add(this.cmdQ);
            this.Controls.Add(this.cmdR);
            this.Controls.Add(this.cmdI);
            this.Controls.Add(this.cmdJ);
            this.Controls.Add(this.cmdK);
            this.Controls.Add(this.cmdL);
            this.Controls.Add(this.cmdŁ);
            this.Controls.Add(this.cmdM);
            this.Controls.Add(this.cmdN);
            this.Controls.Add(this.cmdŃ);
            this.Controls.Add(this.cmdH);
            this.Controls.Add(this.cmdĄ);
            this.Controls.Add(this.cmdB);
            this.Controls.Add(this.cmdC);
            this.Controls.Add(this.cmdĆ);
            this.Controls.Add(this.cmdD);
            this.Controls.Add(this.cmdE);
            this.Controls.Add(this.cmdĘ);
            this.Controls.Add(this.cmdF);
            this.Controls.Add(this.cmdG);
            this.Controls.Add(this.cmdA);
            this.Controls.Add(this.HangImage);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmHang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Szubienica";
            this.Load += new System.EventHandler(this.frmHang_Load);
            ((System.ComponentModel.ISupportInitialize)(this.HangImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox HangImage;
        private System.Windows.Forms.Button cmdA;
        private System.Windows.Forms.Button cmdG;
        private System.Windows.Forms.Button cmdF;
        private System.Windows.Forms.Button cmdĘ;
        private System.Windows.Forms.Button cmdE;
        private System.Windows.Forms.Button cmdD;
        private System.Windows.Forms.Button cmdĆ;
        private System.Windows.Forms.Button cmdC;
        private System.Windows.Forms.Button cmdB;
        private System.Windows.Forms.Button cmdĄ;
        private System.Windows.Forms.Button cmdI;
        private System.Windows.Forms.Button cmdJ;
        private System.Windows.Forms.Button cmdK;
        private System.Windows.Forms.Button cmdL;
        private System.Windows.Forms.Button cmdŁ;
        private System.Windows.Forms.Button cmdM;
        private System.Windows.Forms.Button cmdN;
        private System.Windows.Forms.Button cmdŃ;
        private System.Windows.Forms.Button cmdH;
        private System.Windows.Forms.Button cmdR;
        private System.Windows.Forms.Button cmdQ;
        private System.Windows.Forms.Button cmdP;
        private System.Windows.Forms.Button cmdó;
        private System.Windows.Forms.Button cmdO;
        private System.Windows.Forms.Button cmdV;
        private System.Windows.Forms.Button cmdU;
        private System.Windows.Forms.Button cmdT;
        private System.Windows.Forms.Button cmdŚ;
        private System.Windows.Forms.Button cmdS;
        private System.Windows.Forms.Button cmdŹ;
        private System.Windows.Forms.Button cmdZ;
        private System.Windows.Forms.Button cmdY;
        private System.Windows.Forms.Button cmdX;
        private System.Windows.Forms.Button cmdW;
        private System.Windows.Forms.Button cmdŻ;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Label lblShowWord;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button1;
    }
}

