#### Szubienica ####

*Szubienica to gra towarzyska, polegająca na odgadywaniu słów. Słowo jest wybierane losowo, dlatego też jest możliwość gry w pojedynkę.*

#### Zasady gry ####

*Gracz stara się odgadnąć litery słowa. Za każdym razem, gdy poda prawidłową literkę, pojawia się ona we właściwym miejscu. W przeciwnym wypadku na szubienicy pojawia się wiszący ludzik. Jeżeli gracz odgadnie słowo, zanim na szubienicy pojawi się cały ludzik, wówczas wygrywa, natomiast jeśli nie odgadnie słowa, przegrywa.*